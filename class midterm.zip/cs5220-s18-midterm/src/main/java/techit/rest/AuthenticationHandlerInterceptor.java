package techit.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;
import techit.AppConstants;
import techit.rest.error.RestException;

// TODO Move this into a different package.
public class AuthenticationHandlerInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (request.getRequestURL().toString().endsWith("login")) {
            return true;
        }
        String token = request.getHeader("Authorization");
        if (isTokenValid(token)) {
            return true;
        }
        throw new RestException(401, "Authorization token is missing or invalid");
    }
    
    private boolean isTokenValid(String token) {
        if (token == null) {
            return false;
        }
        if (!token.startsWith(AppConstants.JWT_PREFIX)) {
            return false;
        }
        token = token.substring(AppConstants.JWT_PREFIX.length());
        
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(AppConstants.JWT_SECRET)
                    .parseClaimsJws(token)
                    .getBody();
            Object username = claims.get("username");
            if (username == null) {
                return false;
            }
        }
        catch (ExpiredJwtException | SignatureException e) {
            return false;
        }
        return true;
    }
    
}
